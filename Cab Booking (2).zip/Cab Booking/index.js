var express = require('express');
var app = express();
var server = require('http').Server(app);
var io = require('socket.io').listen(server);
var logger = require('morgan');
var mongoose = require('mongoose');
var routes = require('./server/routes/myroutes');
var tariff = require('./server/routes/tariff');
var cab = require('./server/routes/cab');
var user = require('./server/routes/booking');
var bodyParser = require('body-parser');
var path = require('path');

app.use(logger('dev'));
app.use(bodyParser.json());
app.use('/api', routes);
app.use('/show', tariff);
app.use('/admin', cab);
app.use('/user', user);
app.use(express.static(path.join(__dirname, '/client')));
mongoose.connect('mongodb://localhost/TariffDatabase');

io.set('heartbeat timeout', 4000);
io.set('heartbeat interval', 2000);

io.on('connection', function(socket){
  console.log('Connected');
    //socket.emit('my on event',{my:'hey'});
  socket.on('my on event', function(data){
    // console.log(data);
    // console.log('jjjjj');
    socket.broadcast.emit('my event',{lat:data.lat, lng:data.lng, Email:data.Email});
});

  socket.on('my other on event', function(data){
    socket.broadcast.emit('my other event', {Cname: data.Cname, Cmob:data.Cmob, Pickup: data.Pickup, Destination:data.Destination, CabNo:data.CabNo, Fare:data.Fare});
  })

  socket.on('disconnect', function(data){
    console.log('User Disconnected');
    socket.broadcast.emit('no client event',{my : 'disconnect'});
  });

});

server.listen(8000, function(req, res){
  console.log('Server is running at port no 8000');
});
