var express = require('express');
var router = express.Router();
var UserBooking = require('../models/dbooking.js');

router.post('/BookingDetails', function(req, res){
  var NewUserBooking = new UserBooking({
    CustName: req.body.Cname,
    CustEmail: req.body.Cemail,
    CustMobile: req.body.Cmob,
    PickupLoc: req.body.Origin,
    DestinationLoc: req.body.Destination,
    CabType: req.body.CabType,
    Distance: req.body.Distance,
    Time: req.body.Time,
    Fare: req.body.Fare,
    DriverName: req.body.DriverName,
    DriverEmail: req.body.DriverEmail,
    DriverMob: req.body.DriverMob,
    VehicleNo: req.body.VehicleNo,
    BookingDate: req.body.BookingDate,
    BookingTime: req.body.BookingTime,
    BookingStatus: req.body.BookingStatus,
    DriverBookingStatus: req.body.DriverBookingStatus,
    PickupDate: req.body.PickupDate,
    PickupTime: req.body.PickupTime
  });

  NewUserBooking.save(function(err){
    if(err){
      throw err;
    } else {
      console.log('Record of User Booking');
      res.json({success:true});
    }
  });
});

router.get('/GetBooking', function(req, res){
    UserBooking.find({}, function(err, data){
      if(err){
        throw err;
      } else {
        res.json(data);
      }
    });
});

router.get('/CustBooking/:id', function(req, res){
  UserBooking.find({
    CustEmail: req.params.id
  }, function(err, data){
    if(err){
      throw err;
    } else {
      res.json(data);
    }
  });
});

router.get('/DriBooking/:id', function(req, res){
  UserBooking.find({
    DriverEmail: req.params.id
  }, function(err, data){
    if (err){
      throw err;
    } else {
      res.json(data);
    }
  });
});

router.get('/Booking/:DriverEmail/:DriverBookingStatus', function(req, res){
  UserBooking.findOne({
    DriverEmail: req.params.DriverEmail,
    DriverBookingStatus: req.params.DriverBookingStatus
  }, function(err, data){
    if(err){
      throw err;
    } else {
      res.json(data);
      console.log(data);
    }
  });
});

router.put('/EditBooking/:data', function(req, res){
  UserBooking.update({
    _id: req.params.data
  }, {$set:{DriverBookingStatus:req.body.DriverBookingStatus,
            DriverName: req.body.DriverName,
            VehicleNo: req.body.VehicleNo,
            DriverEmail: req.body.DriverEmail,
            DriverMob: req.body.DriverMob
          }}, function(err, data){
            if(err){
              throw err;
            } else {
              res.json(data);
            }
          });
});

router.delete('/DeleteBooking/:id', function(req, res){
  UserBooking.remove({
    _id:req.params.id
  }, function(err, data){
    if(err){
      throw err;
    } else {
      res.json(data);
      console.log('Record Deleted');
    }
  });
});

module.exports = router;
