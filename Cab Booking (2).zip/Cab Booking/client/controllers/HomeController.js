angular.module('myApp').controller('HomeController', function($scope){

});
