angular.module('myApp').controller('MyRidesController', function($scope, $http){

$scope.getRides = function() {
    $scope.Cemail = sessionStorage.getItem('cust_id');
  $http.get('/user/CustBooking/'+$scope.Cemail).then(function(response){
    console.log(response.data);
    $scope.rides = response.data;
  });

}

$scope.getRides();

$scope.DeleteRides = function(id){
  console.log(id);
      $http.delete('/user/DeleteBooking/'+id).then(function(response){

      }, function(response){
       console.log(response);
     });
     alert('Record Deleted');
}

});
