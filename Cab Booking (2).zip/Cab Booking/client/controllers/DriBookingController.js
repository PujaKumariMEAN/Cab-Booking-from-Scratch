angular.module('myApp').controller('DriBookingController', function($scope, $http, $rootScope, $sessionStorage){

   $scope.dlat;
   $scope.dlng;
   $scope.driEmail=sessionStorage.getItem('dri_id');
   console.log("Driver id "+$scope.driEmail);

   $scope.BookedRides = function(){
     $http.get('/user/DriBooking/'+$scope.driEmail).then(function(response){
            console.log(response.data);
            $scope.booked=response.data;
     });
   }

$scope.BookedRides();

   var map, infoWindow, marker;
  $scope.initMap = function(){
  // var LatLng = new google.maps.LatLng(28.5733, 77.2219);
   map = new google.maps.Map(document.getElementById('drimap'),{
       zoom : 15,
       center : {lat: -34.397, lng: 150.644}
    });

    infoWindow = new google.maps.InfoWindow;

    if(navigator.geolocation){
      navigator.geolocation.getCurrentPosition(function(position){
        var pos = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };

        $scope.dlat=pos.lat;
        $scope.dlng=pos.lng;
        console.log("the value of dlat"+$scope.dlat);
        infoWindow.setPosition(pos);
        infoWindow.setContent('My Location');
        infoWindow.open(map);
        map.setCenter(pos);

        var image = {
          url: '../public/images/cab.png',
          size: new google.maps.Size(71, 71),
          origin: new google.maps.Point(0, 0),
          anchor: new google.maps.Point(17, 34),
          scaledSize: new google.maps.Size(80, 60)
        };

         marker = new google.maps.Marker({
          position: pos,
          icon: image,
          map: map
        });

        var socket = io.connect('http://localhost:8000');
        // socket.broadcast.emit('my event', {lat:$scope.dlat, lng:$scope.dlng, Email:$scope.driEmail});
     //     // socket.broadcast.emit('my event', {my : "hey"});
     socket.emit('my on event', {lat:$scope.dlat, lng:$scope.dlng, Email:$scope.driEmail});
     socket.emit('disconnect', {my: 'disconnect1'});
        socket.on('my event', function(data){
          console.log("inside socket");
          console.log(data.Email);
        });

          }, function(){
            handleLocationError(true, infoWindow, marker, map.getCenter());
          });
        } else {
          handleLocationError(false, infoWindow, marker, map.getCenter());
        }

    }

    function handleLocationError(browserHasGeolocation, infoWindow, pos) {
         infoWindow.setPosition(pos);
         infoWindow.setContent(browserHasGeolocation ?
                               'Error: The Geolocation service failed.' :
                               'Error: Your browser doesn\'t support geolocation.');
         infoWindow.open(map);
            }

    $scope.getCab = function(){
      var d_email=sessionStorage.getItem('dri_id');
      // var drivername = sessionStorage.getItem('dri_name');
      // var drivercontact = sessionStorage.getItem('dri_mob');
      // console.log(drivercontact);
      // console.log(drivername);
      $http.get('/user/GetBooking').then(function(response){
            $http.get('/admin/GetCab/'+d_email).then(function(response){
                  // console.log(d_email);
                  // console.log(response.data);
                  // console.log(response.data[0].CabNo);
                  var cabNo = response.data[0].CabNo;
                  // console.log(cabNo);
            });
       });
    }
    $scope.getCab();

    $scope.t = $scope.t;
    var a = $scope.t;

    // $scope.SaveData = function(){
    //   $scope.s.lat = $scope.dlat;
    //   $scope.s.lng = $scope.dlng;
    //   $http.post('/loc/Location',$scope.s).then(function(response){
    //     console.log(response);
    //   });
    // };

    var a1;

    var socket1 = io.connect('http://localhost:8000');
    socket1.on('my other event', function(data){
        $scope.Custname = data.Cname;
        $scope.Pickup = data.Pickup;
        $scope.Destination = data.Destination;
        $scope.CustMob = data.Cmob;
        $scope.Fare = data.Fare;

        if($scope.Custname!=undefined)

        {
          $scope.NewDetails();
        }
    });

    $scope.NewDetails = function(){
      $('#detailModal').on('show.bs.modal', function(){
        $(this).find('#Custname').text($scope.Custname);
        $(this).find('#Pickup').text($scope.Pickup);
        $(this).find('#Destination').text($scope.Destination);
        $(this).find('#CustMob').text($scope.CustMob);
        $(this).find('#Fare').text($scope.Fare);
      });

      $('#Cname').html($scope.Custname);
      $('#PLoc').html($scope.Pickup);
      $('#DLoc').html($scope.Destination);
      $('#Mob').html($scope.CustMob);
      $('#f1').html($scope.Fare);
      sessionStorage.setItem('cabno', $scope.Fare);
      $('#detailModal').modal('show');
          $scope.BookingData();
    }

    $scope.BookingData = function(){
      $scope.demail = sessionStorage.getItem('dri_id');
      $scope.DriverBookingStatus = "booked";
      $http.get('/user/Booking/'+$scope.demail+'/'+$scope.DriverBookingStatus).then(function(response){
        console.log(response.data);
        $scope.cust=response.data;
      });
    }

    $scope.BookingData();

    $scope.getBookings = function(id){
      $scope.demail = sessionStorage.getItem('dri_id');
      $http.get('/user/DriBooking/'+$scope.demail).then(function(response){
         console.log(response.data);
         $scope.yourBooking = response.data;
      });
    }

   $scope.getBookings();

   $scope.Delete = function(id){
     console.log(id);
         $http.delete('/user/DeleteBooking/'+id).then(function(response){

         }, function(response){
          console.log(response);
        });
        alert('Record Deleted Successfully');
   }

});
