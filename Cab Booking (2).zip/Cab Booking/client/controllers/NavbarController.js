angular.module('myApp').controller('NavbarController', function($scope, $rootScope){

  // $rootScope.login=false;
  // $rootScope.sign=false;
  // $rootScope.admin=true;
  // $rootScope.tariff=true;
  // $rootScope.cabdriverdetail=true;
  // $rootScope.booking=true;
  // $rootScope.dribooking=true;
  // $rootScope.logout=true;
  // $rootScope.changepassword=true;
  // $rootScope.user=true;
});
