angular.module('myApp').controller('ChangePasswordController', function($scope, $http, AuthenticationServices, $sessionStorage,  $location){

  $scope.submitForm = function(isValid) {
      if (isValid) {
        alert('our form is amazing');
      }
    };

    $scope.changepassword = function(){
      var newp = $scope.Change.NewPassword;
      var Cust = sessionStorage.getItem('cust_id');
      var Driver = sessionStorage.getItem('dri_id');
      var Admin = sessionStorage.getItem('admin_id');

      if(Cust!=null)
      {
        $scope.Change.Email = Cust;
        console.log(Cust);
      }
      else if(Driver!=null)
      {
        $scope.Change.Email = Driver;
        console.log(Driver);
      }
      else if(Admin!=null)
      {
        $scope.Change.Email = Admin;
        console.log(Admin);
      }
      console.log(  $scope.Change);

        if(Cust!=""||Driver!=""||Admin!="")
        {
          AuthenticationServices.Login($scope.Change, function(response){
            console.log(response);
              if(response.data.invalid!=true){
                $scope.Email = $scope.Change.Email;
                $http.put('/api/ChangePassword/'+$scope.Email, $scope.Change).then(function(response){
                  console.log(response);
                  if(response.statusText=="OK")
                  {
                    alert("Password Updated!");
                  } else
                  {
                    alert("Please try again");
                  }

                });
              }
              else
               {
                alert("Invalid Password");
              }
          });

        }
      }


});
