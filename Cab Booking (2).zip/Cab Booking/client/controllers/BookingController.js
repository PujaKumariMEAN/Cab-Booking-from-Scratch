angular.module('myApp').controller('BookingController', function($scope, $http, $sessionStorage){

   $scope.now1=true;
   $scope.later1=true;
   $scope.panel=true;
   $scope.drilogin = true;
   $scope.lat;

   var marker1;
   $scope.submitForm = function(isValid) {

    // check to make sure the form is completely valid
    if (isValid) {
      alert('our form is amazing');
    }

  };


   var socket = io.connect('http://localhost:8000');
   socket.on('my event', function(data){
     console.log("lat"+data.lat);
     console.log("lng"+data.lng);

     $scope.driEmail = data.Email;
     console.log(data.Email);

     if(data.Email!=undefined){
       console.log("enable");
       $scope.enable=false;
     } else {
       console.log("opaosp");
       $scope.enable = true;
     }

   });

   socket.on('no client event', function(data){
     console.log("No one has logged on");
   });

     var cabtype = function(){
       $http.get('/show/GetTariff1').then(function(response){
         console.log(response);
         $scope.CabTyp=response.data;
         // console.log($scope.CabTyp[0].CabType);
       });
     };
     cabtype();

   var driverdata = function(){
     if($scope.driEmail!=undefined){
       console.log($scope.driEmail);
       $scope.enable = false;
     }     else {
         console.log("not logged");
         $scope.enable = true;
     }
     $http.get('/admin/GetDetails').then(function(response){
       console.log(response);
       $scope.vehicletype=response.data;
       // console.log($scope.vehicletype[0].CabType);
       // console.log($scope.lat);
     });

     socket.on('my event', function(data){
       $scope.lat = data.lat;
       console.log($scope.lat);
       $scope.driEmail = data.Email;
       console.log(data.Email);
       if($scope.driEmail!=undefined){
         console.log("enable");
         $scope.enable = false;
       } else {
         console.log("not logged");
         $scope.enable = true;
       }
     });
     // console.log($scope.lat);
   };

   driverdata();

  $scope.UserBookingDetails = function(){
    $scope.User.Cemail = sessionStorage.getItem('cust_id');
    $scope.User.Cname = sessionStorage.getItem('cust_name');
    $scope.Cname=$scope.User.Cname;
    $scope.User.Cmob = sessionStorage.getItem('cust_mob');
    $scope.Cmob = $scope.User.Cmob;
    $scope.CabType = $scope.User.CabType;
    $scope.Origin = $scope.User.Origin;
    $scope.Destination = $scope.User.Destination;
    $scope.demail = $scope.driEmail;
    $scope.User.Distance= document.getElementById('tdistance').innerHTML;
    $scope.User.Time= document.getElementById('time').innerHTML;
    $scope.User.Fare= document.getElementById('fare').innerHTML;
    $scope.Fare = $scope.User.Fare;
    var todayDate = new Date();
    var date1 = todayDate.getFullYear()+'-'+(todayDate.getMonth()+1)+'-'+todayDate.getDate();
    var time1 = todayDate.getHours()+":"+todayDate.getMinutes()+":"+todayDate.getSeconds();
    $scope.User.BookingDate = date1;
    $scope.User.BookingTime = time1;
    $scope.PickupDate = $scope.User.PickupDate;
    $scope.User.PickupTime = document.getElementById('time1').value;
    $scope.PickupTime = $scope.User.PickupTime;

    $http.get('/admin/Driver/'+$scope.demail).then(function(response){
      console.log(response.data);
      if(response.data==undefined || $scope.drilogin==false){
        alert("No Cab available");
      } else {
        $scope.User.DriverName = response.data.FirstName;
        $scope.User.VehicleNo = response.data.CabNo;
        $scope.cabno = $scope.User.VehicleNo;
        $scope.User.DriverMob = response.data.Contact;
        $scope.User.DriverEmail = response.data.Email;
        $scope.driEmail = $scope.User.DriverEmail;
        $scope.User.CabType = response.data.CabType;
        $scope.cabt = $scope.User.CabType;
        $scope.driName = true;
        sessionStorage.setItem('VehicleNo', $scope.cabno);

        $scope.User.BookingStatus = "Booked";
        $scope.DriverBookingStatus = "Booked";
        $scope.User.DriverBookingStatus = $scope.DriverBookingStatus;
        // if($scope.cabt!=$scope.CabType){
        //      alert(" This Cab is not available");
        //
        // }
      }
    });
     $scope.cab=true;
    $http.get('/user/Booking/'+$scope.driEmail+'/'+$scope.DriverBookingStatus).then(function(response){
      // console.log(response.data);

      if(response.data!=null ||$scope.cabt!=$scope.CabType){
        alert('This Cab is Already Booked or not Available');
      }
      else
      {
        console.log("Cab "+$scope.cab+" and Driver "+$scope.driName);

            if($scope.cab==true && $scope.driName==true){
              $http.post('/user/BookingDetails',$scope.User).then(function(response){
                if(response.data.success)
                {
                  var socket = io.connect('http://localhost:8000');
                  socket.emit('my other on event', {Cname: $scope.Cname, Cmob:$scope.Cmob, Pickup: $scope.Origin, Destination:$scope.Destination, CabNo:$scope.cabno, Fare:$scope.Fare});
                  $("#detailModal").modal('show');
                }
              });
        }
        else {
          alert("This Cab is not Available");
        }
      }
    });
  }


  $scope.LaterBooking = function(){
     $scope.CabType = $scope.User.CabType;
     console.log($scope.CabType);
     $http.get('/show/GetTariffCab/'+$scope.CabType).then(function(response){
       var d= document.getElementById('tdistance').innerHTML;
       var t= document.getElementById('time').innerHTML;
       var d1 = d.split(" ");
       var t1 = t.split(" ");

       var lateTime =document.getElementById('time1').value;
       // console.log(lateTime);
       var ltime = lateTime.split(" ");
       // console.log(ltime[0]);
       var ltime1 = ltime[0].split(":");
       // console.log(ltime1[0]);
       // console.log(ltime1[1]);
       var timeLate = new Date();
       timeLate.setHours(ltime1[0], ltime1[1]);


        var StartPeak = response.data.StartPeak;
        var speak = StartPeak.split(':');
        // console.log(speak);
        var s = speak[1].split(" ");
        // console.log(s);
        // console.log(speak[0]);
        // console.log(s[0]);
       var startp = new Date();
        startp.setHours(speak[0], s[0]);

        var EndPeak = response.data.EndPeak;
        var epeak = EndPeak.split(':');
        // console.log(epeak);
        var e = epeak[1].split(" ");
        // console.log(e);
        // console.log(epeak[0]);
        // console.log(e[0]);
        var endp = new Date();
        endp.setHours(epeak[0], e[0]);

        if(timeLate>=startp  && timeLate<=endp)
        {
          $scope.rate = response.data.PeakRate;
          console.log(response.data.PeakRate);
        }
        else
         {
          $scope.rate = response.data.NormalRate;
          console.log(response.data.NormalRate);
        }

                $scope.fare = parseInt((d1[0]*$scope.rate));
                 document.getElementById('latefare').value = $scope.fare;
                 console.log($scope.fare);
     });
   }

  $scope.initMap = function(){

   var map;
   var start = document.getElementById('origin-input');
   start =[];
   // var infowindow = new google.maps.InfoWindow;

   // var geocoder = new google.maps.Geocoder();
   var geocoder, location1, location2;

   infoWindow = new google.maps.InfoWindow;

   map = new google.maps.Map(document.getElementById('map'),{
      zoom : 15,
      center : { lat:28.5733 , lng: 77.2219},
      mapTypeId: google.maps.MapTypeId.ROADMAP
   });

   // console.log($scope.lat);

   // // start.push("h");
   // // document.getElementById('origin-input').value = start[0];
   // // console.log(start[0]);

   if(navigator.geolocation){
     navigator.geolocation.getCurrentPosition(function(position){
       var pos = {
         lat: position.coords.latitude,
         lng: position.coords.longitude
       };
       infoWindow.setPosition(pos);
       infoWindow.setContent('My Current Location')
       infoWindow.open(map);
       map.setCenter(pos);

       var image = {
         url: '../public/images/p_logo.png',
         size: new google.maps.Size(61, 61),
         origin: new google.maps.Point(0, 0),
         anchor: new google.maps.Point(17, 34),
         scaledSize: new google.maps.Size(40, 30)
       };

       var marker = new google.maps.Marker({
       position: pos,
       icon: image,
       map: map,
       draggable:true,
       title: "Your Pickup Location"
      });

      var marker;

      google.maps.event.addListener(marker, 'dragend', function(event, geocoder, map, infowindow){
        document.getElementById('lat').value = event.latLng.lat();
        document.getElementById('long').value = event.latLng.lng();
        start.push(document.getElementById('lat').value = event.latLng.lat(), document.getElementById('long').value= event.latLng.lng());
        // document.getElementById('origin-input').value = start;
        console.log(start);
        var latlng = {lat: parseFloat(start[0]), lng: parseFloat(start[1])};
        start.length=0;
                var geocoder = new google.maps.Geocoder();
                 geocoder.geocode({'location': latlng}, function(results, status){
                   if(status === 'OK'){
                     if(results[0]){
                       // map.setZoom(10);
                       var marker = new google.maps.Marker({
                       position: start,
                       icon: image,
                       map: map,
                       draggable:true,
                      });
                      // var infowindow = new google.maps.InfoWindow;
                      // infowindow.setContent(results[0].formatted_address);
                      //     infowindow.open(map, marker);
                          document.getElementById('origin-input').value = results[0].formatted_address;
                          var dlat=results[0].geometry.location.lat();
                          var dlang=results[0].geometry.location.lng();
                          console.log(dlat);
                          console.log(dlang);
                     } else {
                       window.alert('No results found');
                     }
                   } else {
                     window.alert('Geocoder failed due to: ' + status);
                   }
           });
         });

         // var socket = io.connect('http://localhost:8000');
         $scope.drilogin=true;
         socket.on('my event', function(data){
           $scope.lat=data.lat;
           $scope.lng=data.lng;
           var cab_icon = {
           url: '../public/images/cab.png',
           size: new google.maps.Size(71, 71),
           origin: new google.maps.Point(0, 0),
           anchor: new google.maps.Point(17, 34),
           scaledSize: new google.maps.Size(80, 60)
         };

         var latLng = new google.maps.LatLng($scope.lat, $scope.lng);

        marker = new google.maps.Marker({
           position: latLng,
           map: map,
           icon:cab_icon
         });
      });
         map.setZoom(15);
         map.setCenter(marker.getPosition());

         socket.on('no client event', function(data){
           $scope.drilogin=false;
           // $scope.driEmail==" ";
           console.log(data);
           marker.setMap(null);
         });

     var input = document.getElementById('destination-input');
     var searchBox = new google.maps.places.SearchBox(input);

     map.addListener('bounds_changed', function() {
           searchBox.setBounds(map.getBounds());
         });

         // var markers = [];
         searchBox.addListener('places_changed', function() {
           var places = searchBox.getPlaces();

           if (places.length == 0) {
             return;
           }

           // markers.forEach(function(marker) {
           //   marker.setMap(null);
           // });
           // markers = [];

           // For each place, get the icon, name and location.
           var bounds = new google.maps.LatLngBounds();
           places.forEach(function(place) {
             if (!place.geometry) {
               console.log("Returned place contains no geometry");
               return;
             }
             // var image = {
             //   url: '../public/images/cab.png',
             //   size: new google.maps.Size(71, 71),
             //   origin: new google.maps.Point(0, 0),
             //   anchor: new google.maps.Point(17, 34),
             //   scaledSize: new google.maps.Size(80, 60)
             // };
             //
             // markers.push(new google.maps.Marker({
             //   map: map,
             //   icon: image,
             //   title: place.name,
             //   position: place.geometry.location
             // }));

             if (place.geometry.viewport) {
               bounds.union(place.geometry.viewport);
             } else {
               bounds.extend(place.geometry.location);
             }
           });
           map.fitBounds(bounds);
           // var infowindow = new google.maps.InfoWindow({
           //   content: places
           // });
           //
           // google.maps.event.addListener('click', function(){
           //   infowindow.open(map);
           // });

         });

         var directionService = new google.maps.DirectionsService;
         var directionDisplay = new google.maps.DirectionsRenderer({
           map: map
           // panel: document.getElementById('panel_details')
         });

         directionDisplay.setMap(map);

         var onChangeHandler = function() {
           calculateAndDisplayRoute(directionService, directionDisplay);
         };

         document.getElementById('mybtn').addEventListener('click', onChangeHandler);
         // document.getElementById('mybtn').addEventListener('click', getDistance);

         function calculateAndDisplayRoute(directionService, directionDisplay) {

           $scope.User.Origin = document.getElementById('origin-input').value;
           $scope.User.Destination = document.getElementById('destination-input').value;

             directionService.route({
               origin: document.getElementById('origin-input').value,
               destination: document.getElementById('destination-input').value,
               travelMode: 'DRIVING'
             }, function(response, status) {
               if (status === 'OK') {
                 directionDisplay.setDirections(response);
               } else {
                 window.alert('Directions request failed due to ' + status);
               }
             });

             var distService = new google.maps.DistanceMatrixService();
             distService.getDistanceMatrix({
               origins: [$scope.User.Origin],
               destinations: [$scope.User.Destination],
               travelMode: google.maps.TravelMode.DRIVING,
               unitSystem: google.maps.UnitSystem.METRIC,
               avoidHighways: false,
               avoidTolls: false
             }, function(response, status){
               if(status == google.maps.DistanceMatrixStatus.OK && response.rows[0].elements[0].status!= 'ZERO_RESULTS'){
                 var distance = response.rows[0].elements[0].distance.text;
                 var distance1 = distance.replace('km','');
                 $scope.distance = distance1;

                 $scope.now1=false;
                 $scope.later1=false;
                 $scope.panel=false;

                 $scope.User.Distance = parseFloat(distance1);
                 duration = response.rows[0].elements[0].duration.text;

                 var tdistance = document.getElementById('tdistance');
                 tdistance.innerHTML='';
                 tdistance.innerHTML+= distance;
                 var time = document.getElementById('time');
                 time.innerHTML += duration;

                 $scope.CabType = $scope.User.CabType;
                 $http.get('/show/GetTariffCab/'+$scope.CabType).then(function(response){
                   var d= document.getElementById('tdistance').innerHTML;
                   var t= document.getElementById('time').innerHTML;
                   var d1 = d.split(" ");
                   var t1 = t.split(" ");

                   var date = new Date();
                   var h = date.getHours();
                   var m = date.getMinutes();
                   // console.log(h);
                   // console.log(m);
                   var sysDate = new Date();
                   sysDate.setHours(h, m);

                    var StartPeak = response.data.StartPeak;
                    var speak = StartPeak.split(':');
                    // console.log(speak);
                    var s = speak[1].split(" ");
                    // console.log(s);
                    // console.log(speak[0]);
                    // console.log(s[0]);
                   var startp = new Date();
                    startp.setHours(speak[0], s[0]);

                    var EndPeak = response.data.EndPeak;
                    var epeak = EndPeak.split(':');
                    // console.log(epeak);
                    var e = epeak[1].split(" ");
                    // console.log(e);
                    // console.log(epeak[0]);
                    // console.log(e[0]);
                    var endp = new Date();
                    endp.setHours(epeak[0], e[0]);

                    if(sysDate>=startp && sysDate<=endp)
                    {
                      $scope.rate = response.data.PeakRate;
                      console.log(response.data.PeakRate);
                    }
                    else
                     {
                      $scope.rate = response.data.NormalRate;
                      console.log(response.data.NormalRate);
                    }

                            $scope.fare = parseInt((d1[0]*$scope.rate));
                             document.getElementById('fare').innerHTML = $scope.fare;
                 });
               } else {
                 alert('Unable to find the time, distance & fare');
               }
             });  //distance matrix end


           } // end route
    }, function(){
      handleLocationError(true, infoWindow, marker, map.getCenter());
    });

  } else {
    handleLocationError(false, infoWindow, marker, map.getCenter());
  }


} // end initmap fn

  function handleLocationError(browserHasGeolocation, infoWindow, pos) {
     infoWindow.setPosition(pos);
     infoWindow.setContent(browserHasGeolocation ?
                           'Error: The Geolocation service failed.' :
                           'Error: Your browser doesn\'t support geolocation.');
     infoWindow.open(map);
        }

        $scope.Userdetail = function(){
          var custid = sessionStorage.getItem('cust_id');
          var custname = sessionStorage.getItem('cust_name');
          var custmob = sessionStorage.getItem('cust_mob');
          $http.get('/user/GetBooking').then(function(response){
          });
        }
        $scope.Userdetail();


});
