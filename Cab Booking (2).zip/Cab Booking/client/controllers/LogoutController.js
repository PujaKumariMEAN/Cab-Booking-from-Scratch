angular.module('myApp').controller('LogoutController', function($scope, AuthenticationServices, $http, $sessionStorage, $rootScope, $location){

  $scope.logout = function(){
      AuthenticationServices.Logout($scope.User, function(response){
    });

    var socket = io.connect('http://localhost:8000');

    socket.emit('disconnect', {my : 'disconnect1'});
    console.log(socket.emit('disconnect', {my : 'disconnect1'}));
      socket.disconnect();

    sessionStorage.clear();
    $rootScope.login=false;
    $rootScope.sign=false;
    $rootScope.admin=true;
    $rootScope.tariff=true;
    $rootScope.cabdriverdetail=true;
    $rootScope.booking=true;
    $rootScope.dribooking=true;
    $rootScope.logout=true;
    $rootScope.changepassword=true;
    $rootScope.myrides=true;
    $rootScope.user=true;
    $location.path('/');
  }
  $scope.logout();



});
