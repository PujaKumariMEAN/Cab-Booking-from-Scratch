angular.module('myApp').directive('navbar', () => ({
  templateUrl: 'views/navbar.html',
  controller: 'NavbarController',
  restrict: 'E'
}));
