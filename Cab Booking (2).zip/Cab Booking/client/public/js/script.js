$(document).ready(function(){
  $('input.timepicker').click(function(){
     $('#start').timepicki();
     $('#end').timepicki();
     $('#ustart').timepicki();
     $('#uend').timepicki();
     
  });
});
